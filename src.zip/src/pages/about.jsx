import React from 'react'

const About = () => {
  return (
    <div className='container'>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sequi soluta repellendus et neque corrupti earum exercitationem porro consequatur! Quas nisi quisquam doloribus nobis nulla aliquid aspernatur sunt nostrum sed amet!</div>
  )
}

export default About